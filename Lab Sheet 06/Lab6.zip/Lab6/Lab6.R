setwd("C:\\Users\\chama\\OneDrive - Sri Lanka Institute of Information Technology\\Probability and Statistics - IT2120\\Lab\\Lab6")
# random variable X has binomial distribution with n = 50 and p = 0.85

1 - pbinom(46, size = 50, prob = 0.85)

# Random variable X = number of calls received in an hour
# Therefore, X follows a Poisson distribution with λ = 12

# Distribution of X
#  X ~ Poisson(λ = 12)

dpois(15, lambda = 12)


