setwd("C:\\Users\\chama\\OneDrive - Sri Lanka Institute of Information Technology\\Probability and Statistics - IT2120\\Lab\\Lab7")

#1
punif(25, min=0, max=40, lower.tail = TRUE) - punif(10, min=0, max=40, lower.tail = TRUE)

#2
pexp(2, rate=1/3, lower.tail = TRUE)

#3(i.)
1 - pnorm(130, mean=100, sd=15, lower.tail = TRUE)

(ii.)
qnorm(0.95, mean=100, sd=15, lower.tail = TRUE)